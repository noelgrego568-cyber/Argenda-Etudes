package com.agendaetudes.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        String title=in.getStringExtra("title"); if(title==null) title="Agenda Études";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("agenda_reminders","Rappels de l'agenda",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        nm.notify(in.getIntExtra("id",1),new NotificationCompat.Builder(c,"agenda_reminders").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Agenda Études").setContentText(title).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build());
        AlarmScheduler.scheduleAll(c);
    }
}
