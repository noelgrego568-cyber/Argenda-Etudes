package com.agendaetudes.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmScheduler {
    public static void scheduleAll(Context c) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null) return;
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
        for(int i=0;i<140;i++) {
            Intent cancel=new Intent(c,ReminderReceiver.class).putExtra("id",i);
            PendingIntent old=PendingIntent.getBroadcast(c,i,cancel,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(old!=null) am.cancel(old);
        }
        java.util.ArrayList<Reminder> list=ReminderStore.load(c);
        for(int i=0;i<list.size();i++) {
            Reminder r=list.get(i); if(!r.enabled) continue;
            String[] p=r.time.split(":"); int hour=Integer.parseInt(p[0]), min=Integer.parseInt(p[1]);
            Calendar now=Calendar.getInstance();
            for(int add=0;add<14;add++) {
                Calendar when=(Calendar)now.clone(); when.add(Calendar.DAY_OF_YEAR,add); when.set(Calendar.HOUR_OF_DAY,hour); when.set(Calendar.MINUTE,min); when.set(Calendar.SECOND,0); when.set(Calendar.MILLISECOND,0);
                String dow=new SimpleDateFormat("EEE",Locale.US).format(when.getTime()).toUpperCase(Locale.US).substring(0,2);
                boolean day=r.days.equals("TOUS") || (","+r.days+",").contains(","+dow+",");
                String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(when.getTime());
                if(day && date.compareTo(r.endDate)<=0 && when.after(now)) {
                    int id=i*20+add;
                    Intent in=new Intent(c,ReminderReceiver.class).putExtra("title",r.title).putExtra("id",id);
                    PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
                }
            }
        }
    }
}
