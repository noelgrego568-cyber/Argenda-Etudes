package com.agendaetudes.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    ArrayList<Reminder> items;
    LinearLayout list;
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        items=ReminderStore.load(this);
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
        showScreen();
    }
    void showScreen() {
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,36,36,36); root.setBackgroundColor(0xFFF4F6FA); scroll.addView(root);
        TextView title=new TextView(this); title.setText("Agenda Études"); title.setTextSize(28); title.setTextColor(0xFF183B70); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=new TextView(this); sub.setText("Orè pèsonèl • kou • rapèl"); sub.setTextSize(15); sub.setGravity(Gravity.CENTER); sub.setPadding(0,8,0,24); root.addView(sub);
        status=new TextView(this); status.setText("Alam yo repete selon jou ou chwazi yo. Fen peryòd pa default: 31 me 2027."); status.setTextSize(14); status.setPadding(0,0,0,18); root.addView(status);
        Button add=new Button(this); add.setText("+ Ajoute yon rapèl"); add.setOnClickListener(v->editReminder(-1)); root.addView(add);
        Button enable=new Button(this); enable.setText("Aktive / replanifye alam yo"); enable.setOnClickListener(v->{
            if(Build.VERSION.SDK_INT>=31 && !((android.app.AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms()) { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
            else { AlarmScheduler.scheduleAll(this); Toast.makeText(this,"Alam yo replanifye",Toast.LENGTH_LONG).show(); }
        }); root.addView(enable);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list); refreshList(); setContentView(scroll);
    }
    void refreshList() {
        list.removeAllViews();
        for(int i=0;i<items.size();i++) { final int index=i; Reminder r=items.get(i);
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(20,18,20,18); card.setBackgroundColor(0xFFFFFFFF); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,10,0,10); list.addView(card,lp);
            TextView t=new TextView(this); t.setText(r.time+"  •  "+r.title); t.setTextSize(18); t.setTextColor(0xFF18243A); card.addView(t);
            TextView d=new TextView(this); d.setText("Jou: "+(r.days.equals("TOUS")?"Chak jou":r.days)+"   |   Jiska: "+r.endDate+"   |   "+(r.enabled?"Aktif":"Inaktif")); d.setTextSize(13); card.addView(d);
            LinearLayout actions=new LinearLayout(this); Button edit=new Button(this); edit.setText("Modifye"); edit.setOnClickListener(v->editReminder(index)); actions.addView(edit);
            Button toggle=new Button(this); toggle.setText(r.enabled?"Mete poz": "Aktive"); toggle.setOnClickListener(v->{items.get(index).enabled=!items.get(index).enabled; saveAndRefresh();}); actions.addView(toggle);
            Button del=new Button(this); del.setText("Efase"); del.setOnClickListener(v->{items.remove(index);saveAndRefresh();}); actions.addView(del); card.addView(actions);
        }
    }
    void editReminder(int idx) {
        Reminder old=idx<0?new Reminder("Nouvo aktivite","07:00","TOUS","2027-05-31",true):items.get(idx);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(36,8,36,8);
        EditText name=new EditText(this); name.setSingleLine(); name.setHint("Non aktivite a"); name.setText(old.title); box.addView(name);
        EditText time=new EditText(this); time.setSingleLine(); time.setHint("Lè HH:MM (eg. 07:30)"); time.setText(old.time); box.addView(time);
        EditText days=new EditText(this); days.setSingleLine(); days.setHint("TOUS oswa MO,TU,WE,TH,FR,SA,SU"); days.setText(old.days); box.addView(days);
        EditText end=new EditText(this); end.setSingleLine(); end.setHint("Dat fen YYYY-MM-DD"); end.setText(old.endDate); box.addView(end);
        new AlertDialog.Builder(this).setTitle(idx<0?"Ajoute rapèl":"Modifye rapèl").setView(box).setNegativeButton("Anile",null).setPositiveButton("Sove",(dialog,w)->{
            String tm=time.getText().toString().trim(), en=end.getText().toString().trim();
            if(!tm.matches("([01]?[0-9]|2[0-3]):[0-5][0-9]") || !en.matches("\\d{4}-\\d{2}-\\d{2}") || name.getText().toString().trim().isEmpty()) { Toast.makeText(this,"Verifye lè, non ak dat fen an.",Toast.LENGTH_LONG).show(); return; }
            Reminder r=new Reminder(name.getText().toString().trim(),tm,days.getText().toString().trim().toUpperCase(),en,true);
            if(idx<0) items.add(r); else items.set(idx,r); saveAndRefresh();
        }).show();
    }
    void saveAndRefresh(){ ReminderStore.save(this,items); AlarmScheduler.scheduleAll(this); refreshList(); }
}
