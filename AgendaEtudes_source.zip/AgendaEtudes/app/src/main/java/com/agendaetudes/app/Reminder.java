package com.agendaetudes.app;

import org.json.JSONObject;

public class Reminder {
    public String title, time, days, endDate;
    public boolean enabled;
    public Reminder(String title, String time, String days, String endDate, boolean enabled) {
        this.title=title; this.time=time; this.days=days; this.endDate=endDate; this.enabled=enabled;
    }
    public JSONObject toJson() throws Exception {
        JSONObject o=new JSONObject(); o.put("title",title); o.put("time",time); o.put("days",days); o.put("endDate",endDate); o.put("enabled",enabled); return o;
    }
    public static Reminder fromJson(JSONObject o) throws Exception {
        return new Reminder(o.getString("title"),o.getString("time"),o.getString("days"),o.optString("endDate","2027-05-31"),o.optBoolean("enabled",true));
    }
}
