package com.agendaetudes.app;

import android.content.Context;
import org.json.JSONArray;
import java.util.ArrayList;

public class ReminderStore {
    private static final String PREF="agenda_etudes", KEY="reminders";
    public static ArrayList<Reminder> load(Context c) {
        ArrayList<Reminder> a=new ArrayList<>();
        try {
            String raw=c.getSharedPreferences(PREF,0).getString(KEY,null);
            if(raw!=null){ JSONArray ar=new JSONArray(raw); for(int i=0;i<ar.length();i++) a.add(Reminder.fromJson(ar.getJSONObject(i))); }
        } catch(Exception ignored) {}
        if(a.isEmpty()) {
            String until="2027-05-31";
            a.add(new Reminder("Leve", "05:30", "TOUS", until, true));
            a.add(new Reminder("Préparation personnelle", "05:45", "TOUS", until, true));
            a.add(new Reminder("Début du travail personnel", "19:00", "MO,TU,WE,TH,FR,SA", until, true));
            a.add(new Reminder("Préparer demain", "21:00", "TOUS", until, true));
            a.add(new Reminder("Heure de dormir", "22:00", "TOUS", until, true));
            save(c,a);
        }
        return a;
    }
    public static void save(Context c, ArrayList<Reminder> a) {
        try { JSONArray ar=new JSONArray(); for(Reminder r:a) ar.put(r.toJson()); c.getSharedPreferences(PREF,0).edit().putString(KEY,ar.toString()).apply(); } catch(Exception ignored) {}
    }
}
