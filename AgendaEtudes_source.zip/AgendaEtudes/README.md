# Agenda Études — projet Android

Projet source Android Studio (Java) pour une application personnelle de rappels récurrents.

## Fonctions incluses
- Ajouter, modifier, mettre en pause et supprimer des rappels.
- Heure, jours de répétition et date de fin configurables.
- Notifications locales Android avec alarme exacte lorsque l'autorisation est accordée.
- Reprogrammation après redémarrage du téléphone.
- Quelques rappels initiaux (05:30, 05:45, 19:00, 21:00, 22:00).

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Android Studio installer le SDK Android 35 et les dépendances Gradle.
3. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Installer l'APK généré dans `app/build/outputs/apk/debug/`.

## Important
- Ce dépôt est le code source, pas un APK compilé.
- Android 12+ demande l'autorisation « Alarmes et rappels » pour les alarmes exactes; Android 13+ demande aussi l'autorisation de notifications.
- Sur Samsung, autoriser les notifications et vérifier les restrictions de batterie pour que les rappels restent fiables.
- Les horaires de cours détaillés ne sont pas préchargés ici: ajoute-les dans l'application après vérification de ton emploi du temps officiel. La date de fin initiale est le 31 mai 2027 et peut être changée pour chaque rappel.
- Les récurrences sont planifiées sur une fenêtre glissante de 14 jours et se renouvellent après chaque notification.
